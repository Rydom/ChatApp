package com.example.chatapp.Notifications;

public class MyResponse {

    public int sucess;
}
